"""Top-level package for the flythrough backend.

This file marks the ``backend`` directory as a Python package so that
modules such as ``backend.app.main`` can be imported.  It is
deliberately empty.
"""